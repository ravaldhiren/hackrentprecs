import java.io._
import java.math._
import java.security._
import java.text._
import java.util._
import java.util.concurrent._
import java.util.function._
import java.util.regex._
import java.util.stream._
import scala.collection.immutable._
import scala.collection.mutable._
import scala.collection.concurrent._
import scala.collection.parallel.immutable._
import scala.collection.parallel.mutable._
import scala.concurrent._
import scala.io._
import scala.math._
import scala.sys._
import scala.util.matching._
import scala.reflect._

object Solution {



  // Complete the oddNumbers function below.
  def oddNumbers(l: Int, r: Int): Array[Int] = {

    var i = 0

    if (r <= l) return null;

    l = (l % 2) == 0 ? l + 1 : l
    int size = ((r - l) / 2) + 1

    var theArray = new int[size]

    for ( i <- 1 to size) {
      theArray[i] = l + (i*2)
    }

    return theArray

  }

  def main(args: Array[String]) {
    val printWriter = new PrintWriter(sys.env("OUTPUT_PATH"))

    val l = StdIn.readLine.trim.toInt

    val r = StdIn.readLine.trim.toInt

    val res = oddNumbers(l, r)

    printWriter.println(res.mkString("\n"))

    printWriter.close()
  }
}